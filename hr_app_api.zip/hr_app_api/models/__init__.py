# -*- coding: utf-8 -*-
from . import jwt_token_blacklist
from . import hr_resignation
