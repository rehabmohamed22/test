from odoo import models, fields, api


class HrResignation(models.Model):
    _name = 'hr.resignation'
    _description = 'Employee Resignation'

    employee_id = fields.Many2one('hr.employee', string="Employee")
    resignation_date = fields.Date(string="Resignation Date", default=fields.Date.context_today, required=True)
    reason = fields.Text(string="Reason")
    manager_id = fields.Many2one('hr.employee', string="Manager", compute="_compute_employee_info", store=True)
    contract_id = fields.Many2one('hr.contract', string="Contract", compute="_compute_employee_info", store=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ], string='Status', default='draft', tracking=True)

    @api.depends('employee_id')
    def _compute_employee_info(self):
        for rec in self:
            if rec.employee_id:
                rec.manager_id = rec.employee_id.parent_id
                contract = self.env['hr.contract'].search([
                    ('employee_id', '=', rec.employee_id.id),
                    ('state', '=', 'open')  # أو حسب حالتك
                ], limit=1, order='date_start desc')
                rec.contract_id = contract
            else:
                rec.manager_id = False
                rec.contract_id = False

    def action_approve(self):
        for rec in self:
            rec.state = 'approved'

    def action_reject(self):
        for rec in self:
            rec.state = 'rejected'

    def action_reset_to_draft(self):
        for rec in self:
            rec.state = 'draft'