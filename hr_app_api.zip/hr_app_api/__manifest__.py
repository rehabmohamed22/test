{
    'name': 'HR App API',
    'version': '1.0',
    'category': 'Human Resources',
    'summary': 'API to integrate mobile HR app with Odoo',
    'depends': ['base', 'hr'],
    'data': [
        'security/ir.model.access.csv',
        'views/hr_resignation_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
