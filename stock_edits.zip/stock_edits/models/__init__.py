from . import sale_order
from . import account_move
from . import stock_picking
from . import stock_move
from . import product_template
from . import product_product
from . import res_partner
from . import purchase_order
